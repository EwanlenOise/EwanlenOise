n1 = 9
n2 = 99
result = n1+n2
print (result)
